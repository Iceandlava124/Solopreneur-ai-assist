
import { GoogleGenAI, Type, FunctionDeclaration, GenerateContentResponse, LiveSession, LiveServerMessage, Modality, Blob } from "@google/genai";
import type { ImageData, CalendarEvent, Subtask, ChatMessage, GroundingChunk, ModuleId } from '../types';
import { encode } from '../utils/audioUtils';

if (!process.env.API_KEY) {
    console.warn("API_KEY environment variable not set. Please set your API key for the app to function.");
}

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY || "YOUR_API_KEY_HERE" });

type GenerateResponseResult = {
    text: string;
    groundingChunks?: GroundingChunk[];
};

export const generateResponse = async (
    moduleId: ModuleId,
    systemInstruction: string,
    history: ChatMessage[],
    prompt: string,
    image?: ImageData
): Promise<GenerateResponseResult> => {
    try {
        let modelName = 'gemini-2.5-flash-lite';
        let config: any = { systemInstruction };
        
        // Map internal message format to Gemini's history format
        const contents = [
            ...history.map(msg => ({
                role: msg.sender === 'user' ? 'user' : 'model',
                parts: [{ text: msg.text }]
            })),
            {
                role: 'user',
                parts: image 
                    ? [{ inlineData: { mimeType: image.mimeType, data: image.data } }, { text: prompt }]
                    : [{ text: prompt }]
            }
        ];

        switch (moduleId) {
            case 'research':
                modelName = 'gemini-2.5-flash';
                config.tools = [{ googleSearch: {} }];
                break;
            case 'analysis':
                modelName = 'gemini-2.5-pro';
                config.thinkingConfig = { thinkingBudget: 32768 };
                break;
            case 'insights':
                modelName = 'gemini-2.5-flash';
                break;
        }

        const response = await ai.models.generateContent({
            model: modelName,
            contents: contents,
            config: config,
        });

        return {
            text: response.text,
            groundingChunks: response.candidates?.[0]?.groundingMetadata?.groundingChunks as GroundingChunk[],
        };
    } catch (error) {
        console.error(`Error in generateResponse for module ${moduleId}:`, error);
        throw new Error("Failed to generate content from Gemini API.");
    }
};

export const generateImage = async (prompt: string): Promise<string> => {
    try {
        const response = await ai.models.generateImages({
            model: 'imagen-4.0-generate-001',
            prompt: prompt,
            config: { numberOfImages: 1, outputMimeType: 'image/png' },
        });
        return response.generatedImages[0].image.imageBytes;
    } catch (error) {
        console.error("Error in generateImage:", error);
        throw new Error("Failed to generate image.");
    }
};

export const generateSpeech = async (text: string): Promise<string> => {
    try {
        const response = await ai.models.generateContent({
            model: "gemini-2.5-flash-preview-tts",
            contents: [{ parts: [{ text: text }] }],
            config: {
                responseModalities: [Modality.AUDIO],
                speechConfig: {
                    voiceConfig: { prebuiltVoiceConfig: { voiceName: 'Kore' } },
                },
            },
        });
        return response.candidates?.[0]?.content?.parts?.[0]?.inlineData?.data || '';
    } catch (error) {
        console.error("Error in generateSpeech:", error);
        throw new Error("Failed to generate speech.");
    }
};

export const transcribeAudio = async (audioData: { mimeType: string; data: string }): Promise<string> => {
    try {
        const response = await ai.models.generateContent({
            model: 'gemini-2.5-flash',
            contents: {
                parts: [
                    { inlineData: audioData },
                    { text: "Transcribe the following audio." }
                ]
            },
        });
        return response.text;
    } catch(error) {
        console.error("Error in transcribeAudio:", error);
        throw new Error("Failed to transcribe audio.");
    }
}

export const connectToLiveSession = (
    systemInstruction: string,
    callbacks: {
        onopen: () => void;
        onmessage: (message: LiveServerMessage) => void;
        onerror: (e: ErrorEvent) => void;
        onclose: (e: CloseEvent) => void;
    }
): Promise<LiveSession> => {
    return ai.live.connect({
        model: 'gemini-2.5-flash-native-audio-preview-09-2025',
        callbacks: callbacks,
        config: {
            responseModalities: [Modality.AUDIO],
            speechConfig: {
                voiceConfig: { prebuiltVoiceConfig: { voiceName: 'Zephyr' } },
            },
            inputAudioTranscription: {},
            outputAudioTranscription: {},
            systemInstruction: systemInstruction,
        },
    });
};

export function createPcmBlob(data: Float32Array): Blob {
  const l = data.length;
  const int16 = new Int16Array(l);
  for (let i = 0; i < l; i++) {
    int16[i] = data[i] * 32768;
  }
  return {
    data: encode(new Uint8Array(int16.buffer)),
    mimeType: 'audio/pcm;rate=16000',
  };
}


// --- Calendar Specific Functions ---

const addCalendarEventFunctionDeclaration: FunctionDeclaration = {
    name: 'addCalendarEvent',
    description: "Adds an event or task to the user's calendar. Infers the current date if not specified.",
    parameters: {
        type: Type.OBJECT,
        properties: {
            title: { type: Type.STRING, description: 'The title or description of the event.' },
            date: { type: Type.STRING, description: 'The date of the event in YYYY-MM-DD format. Today is ' + new Date().toISOString().slice(0, 10) },
            time: { type: Type.STRING, description: 'The time of the event in HH:MM format (24-hour clock).' },
            priority: { type: Type.STRING, description: 'The priority of the event, can be "low", "medium", or "high". Defaults to "medium".' },
            subtasks: { type: Type.ARRAY, description: 'A list of subtask strings for this event.', items: { type: Type.STRING } }
        },
        required: ['title', 'date', 'time'],
    },
};

const addSubtaskFunctionDeclaration: FunctionDeclaration = {
    name: 'addSubtask',
    description: "Adds a subtask to an existing calendar event.",
    parameters: {
        type: Type.OBJECT,
        properties: {
            parentTaskTitle: { type: Type.STRING, description: "The title of the main event or task to add the subtask to." },
            subtaskTitle: { type: Type.STRING, description: "The title of the subtask to add." }
        },
        required: ['parentTaskTitle', 'subtaskTitle'],
    },
};

const toggleSubtaskCompletionFunctionDeclaration: FunctionDeclaration = {
    name: 'toggleSubtaskCompletion',
    description: "Marks a subtask as complete or incomplete.",
    parameters: {
        type: Type.OBJECT,
        properties: {
            parentTaskTitle: { type: Type.STRING, description: "The title of the main event or task." },
            subtaskTitle: { type: Type.STRING, description: "The title of the subtask to mark as complete or incomplete." }
        },
        required: ['parentTaskTitle', 'subtaskTitle'],
    },
};

type CalendarActionResult =
  | { action: 'ADD_EVENT'; payload: CalendarEvent }
  | { action: 'ADD_SUBTASK'; payload: { parentTaskTitle: string; subtaskTitle: string } }
  | { action: 'TOGGLE_SUBTASK'; payload: { parentTaskTitle: string; subtaskTitle: string } }
  | { action: 'MESSAGE'; payload: string };


export const processCalendarPrompt = async (prompt: string): Promise<CalendarActionResult> => {
    try {
        const response = await ai.models.generateContent({
            model: 'gemini-2.5-flash',
            contents: prompt,
            config: {
                tools: [{ functionDeclarations: [addCalendarEventFunctionDeclaration, addSubtaskFunctionDeclaration, toggleSubtaskCompletionFunctionDeclaration] }],
            },
        });
        
        const functionCalls = response.functionCalls;
        
        if (functionCalls && functionCalls.length > 0) {
            const fc = functionCalls[0];
            const args = fc.args as any;

            if (fc.name === 'addCalendarEvent') {
                const newEvent: CalendarEvent = {
                    id: `evt-${Date.now()}`,
                    title: args.title,
                    date: args.date,
                    time: args.time,
                    priority: args.priority || 'medium',
                    subtasks: args.subtasks ? args.subtasks.map((text: string, index: number) => ({
                        id: `sub-${Date.now()}-${index}`,
                        text,
                        completed: false
                    })) : []
                };
                return { action: 'ADD_EVENT', payload: newEvent };
            }

            if (fc.name === 'addSubtask') {
                return { action: 'ADD_SUBTASK', payload: { parentTaskTitle: args.parentTaskTitle, subtaskTitle: args.subtaskTitle } };
            }

            if (fc.name === 'toggleSubtaskCompletion') {
                return { action: 'TOGGLE_SUBTASK', payload: { parentTaskTitle: args.parentTaskTitle, subtaskTitle: args.subtaskTitle } };
            }
        }

        const textResponse = response.text;
        return { action: 'MESSAGE', payload: textResponse || "I couldn't quite understand that. Could you rephrase your request?" };

    } catch (error) {
        console.error("Error in processCalendarPrompt:", error);
        return { action: 'MESSAGE', payload: "There was an error processing your calendar request." };
    }
};
