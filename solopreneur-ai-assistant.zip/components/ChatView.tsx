
import React, { useState, useRef, ChangeEvent } from 'react';
import type { ChatMessage, MimeType, ImageData, GroundingChunk } from '../types';
import { transcribeAudio } from '../services/geminiService';

interface ChatViewProps {
    messages: ChatMessage[];
    onSendMessage: (text: string, image?: ImageData) => void;
    isLoading: boolean;
    chatEndRef: React.RefObject<HTMLDivElement>;
    showFileUpload: boolean;
    onTextToSpeech: (text: string) => void;
}

const ChatInput: React.FC<Omit<ChatViewProps, 'messages' | 'chatEndRef' | 'onTextToSpeech'>> = ({ onSendMessage, isLoading, showFileUpload }) => {
    const [inputText, setInputText] = useState('');
    const [imagePreview, setImagePreview] = useState<string | null>(null);
    const [imageData, setImageData] = useState<ImageData | null>(null);
    const [isRecording, setIsRecording] = useState(false);
    const fileInputRef = useRef<HTMLInputElement>(null);
    const mediaRecorderRef = useRef<MediaRecorder | null>(null);
    const audioChunksRef = useRef<Blob[]>([]);

    const handleFileChange = (event: ChangeEvent<HTMLInputElement>) => {
        const file = event.target.files?.[0];
        if (file && (file.type === 'image/jpeg' || file.type === 'image/png')) {
            const reader = new FileReader();
            reader.onloadend = () => {
                const base64String = (reader.result as string).split(',')[1];
                setImageData({
                    mimeType: file.type as MimeType,
                    data: base64String,
                });
                setImagePreview(URL.createObjectURL(file));
            };
            reader.readAsDataURL(file);
        }
    };

    const handleSend = () => {
        if ((inputText.trim() || imageData) && !isLoading) {
            onSendMessage(inputText, imageData || undefined);
            setInputText('');
            setImageData(null);
            setImagePreview(null);
            if (fileInputRef.current) {
                fileInputRef.current.value = '';
            }
        }
    };

    const handleKeyPress = (e: React.KeyboardEvent<HTMLInputElement>) => {
        if (e.key === 'Enter') {
            handleSend();
        }
    };

    const startRecording = async () => {
        if (navigator.mediaDevices && navigator.mediaDevices.getUserMedia) {
            try {
                const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
                mediaRecorderRef.current = new MediaRecorder(stream);
                mediaRecorderRef.current.ondataavailable = (event) => {
                    audioChunksRef.current.push(event.data);
                };
                mediaRecorderRef.current.onstop = async () => {
                    const audioBlob = new Blob(audioChunksRef.current, { type: 'audio/webm' });
                    const reader = new FileReader();
                    reader.readAsDataURL(audioBlob);
                    reader.onloadend = async () => {
                        const base64Audio = (reader.result as string).split(',')[1];
                        try {
                           setInputText("Transcribing...");
                           const transcription = await transcribeAudio({ mimeType: 'audio/webm', data: base64Audio});
                           setInputText(transcription);
                        } catch (e) {
                           setInputText("Sorry, couldn't transcribe that.");
                        }
                    };
                    audioChunksRef.current = [];
                    stream.getTracks().forEach(track => track.stop());
                };
                mediaRecorderRef.current.start();
                setIsRecording(true);
            } catch (err) {
                console.error("Error accessing microphone:", err);
            }
        }
    };

    const stopRecording = () => {
        if (mediaRecorderRef.current && isRecording) {
            mediaRecorderRef.current.stop();
            setIsRecording(false);
        }
    };

    const toggleRecording = () => {
        isRecording ? stopRecording() : startRecording();
    };


    return (
        <div className="bg-white border-t border-gray-200 p-4 mt-auto">
            {imagePreview && (
                <div className="relative w-24 h-24 mb-2">
                    <img src={imagePreview} alt="Preview" className="w-full h-full object-cover rounded-md" />
                    <button 
                        onClick={() => { setImagePreview(null); setImageData(null); if(fileInputRef.current) fileInputRef.current.value = ''; }}
                        className="absolute -top-2 -right-2 bg-red-500 text-white rounded-full w-6 h-6 flex items-center justify-center text-xs">&times;</button>
                </div>
            )}
            <div className="flex items-center bg-gray-100 rounded-full p-2">
                {showFileUpload && (
                    <>
                        <input type="file" accept="image/png, image/jpeg" ref={fileInputRef} onChange={handleFileChange} className="hidden" />
                        <button onClick={() => fileInputRef.current?.click()} className="p-2 text-gray-500 hover:text-brand-primary rounded-full transition-colors">
                            <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M21.44 11.05l-9.19 9.19a6 6 0 0 1-8.49-8.49l9.19-9.19a4 4 0 0 1 5.66 5.66l-9.2 9.19a2 2 0 0 1-2.83-2.83l8.49-8.48"></path></svg>
                        </button>
                    </>
                )}
                <button onClick={toggleRecording} className={`p-2 rounded-full transition-colors ${isRecording ? 'text-red-500 animate-pulse' : 'text-gray-500 hover:text-brand-primary'}`}>
                     <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M12 1a3 3 0 0 0-3 3v8a3 3 0 0 0 6 0V4a3 3 0 0 0-3-3z"></path><path d="M19 10v2a7 7 0 0 1-14 0v-2"></path><line x1="12" y1="19" x2="12" y2="23"></line></svg>
                </button>
                <input
                    type="text"
                    value={inputText}
                    onChange={(e) => setInputText(e.target.value)}
                    onKeyPress={handleKeyPress}
                    placeholder="Type your message or command..."
                    className="flex-1 bg-transparent border-none focus:ring-0 outline-none px-4 text-gray-700"
                    disabled={isLoading}
                />
                <button
                    onClick={handleSend}
                    disabled={isLoading || (!inputText.trim() && !imageData)}
                    className="p-2 bg-brand-secondary text-white rounded-full hover:bg-brand-primary disabled:bg-gray-300 transition-colors"
                >
                    <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><line x1="22" y1="2" x2="11" y2="13"></line><polygon points="22 2 15 22 11 13 2 9 22 2"></polygon></svg>
                </button>
            </div>
        </div>
    );
};


export const ChatView: React.FC<ChatViewProps> = ({ messages, onSendMessage, isLoading, chatEndRef, showFileUpload, onTextToSpeech }) => {
    return (
        <div className="flex flex-col h-full w-full max-w-4xl mx-auto bg-white rounded-lg shadow-lg">
            <div className="flex-1 p-6 overflow-y-auto">
                {messages.map((msg) => (
                    <div key={msg.id} className={`flex my-4 animate-fade-in ${msg.sender === 'user' ? 'justify-end' : 'justify-start'}`}>
                        <div className={`relative group max-w-lg lg:max-w-xl px-4 py-3 rounded-2xl ${msg.sender === 'user' ? 'bg-brand-secondary text-white rounded-br-none' : 'bg-gray-200 text-gray-800 rounded-bl-none'}`}>
                            {msg.sender === 'ai' && (
                                <button onClick={() => onTextToSpeech(msg.text)} className="absolute top-1 right-1 p-1 text-gray-400 hover:text-brand-primary opacity-0 group-hover:opacity-100 transition-opacity">
                                    <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><polygon points="11 5 6 9 2 9 2 15 6 15 11 19 11 5"></polygon><path d="M19.07 4.93a10 10 0 0 1 0 14.14M15.54 8.46a5 5 0 0 1 0 7.07"></path></svg>
                                </button>
                            )}
                            {msg.image && <img src={`data:${msg.image.mimeType};base64,${msg.image.data}`} alt="uploaded content" className="rounded-lg mb-2 max-h-60" />}
                            {msg.generatedImage && <img src={`data:image/png;base64,${msg.generatedImage}`} alt="generated content" className="rounded-lg mb-2" />}
                            <p className="whitespace-pre-wrap">{msg.text}</p>
                            {msg.groundingChunks && msg.groundingChunks.length > 0 && (
                                <div className="mt-3 pt-3 border-t border-gray-300">
                                    <h4 className="text-xs font-bold text-gray-600 mb-1">Sources:</h4>
                                    <ul className="text-xs space-y-1">
                                        {msg.groundingChunks.map((chunk, i) => (
                                            <li key={i}><a href={chunk.web.uri} target="_blank" rel="noopener noreferrer" className="text-blue-600 hover:underline truncate block">{chunk.web.title}</a></li>
                                        ))}
                                    </ul>
                                </div>
                            )}
                        </div>
                    </div>
                ))}
                 {isLoading && (
                    <div className="flex my-4 justify-start">
                        <div className="max-w-lg lg:max-w-xl px-4 py-3 rounded-2xl bg-gray-200 text-gray-800 rounded-bl-none">
                            <div className="flex items-center space-x-2">
                                <div className="w-2 h-2 bg-gray-500 rounded-full animate-pulse"></div>
                                <div className="w-2 h-2 bg-gray-500 rounded-full animate-pulse [animation-delay:0.2s]"></div>
                                <div className="w-2 h-2 bg-gray-500 rounded-full animate-pulse [animation-delay:0.4s]"></div>
                            </div>
                        </div>
                    </div>
                )}
                <div ref={chatEndRef} />
            </div>
            <ChatInput onSendMessage={onSendMessage} isLoading={isLoading} showFileUpload={showFileUpload} />
        </div>
    );
};
