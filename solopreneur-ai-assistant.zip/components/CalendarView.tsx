
import React from 'react';
import type { CalendarEvent } from '../types';

interface CalendarViewProps {
    events: CalendarEvent[];
    onToggleSubtask: (eventId: string, subtaskId: string) => void;
}

const PriorityBadge: React.FC<{ priority: 'low' | 'medium' | 'high' }> = ({ priority }) => {
    const priorityClasses = {
        low: 'bg-green-100 text-green-800',
        medium: 'bg-yellow-100 text-yellow-800',
        high: 'bg-red-100 text-red-800',
    };
    return (
        <span className={`px-2 py-1 text-xs font-medium rounded-full ${priorityClasses[priority]}`}>
            {priority}
        </span>
    );
};

export const CalendarView: React.FC<CalendarViewProps> = ({ events, onToggleSubtask }) => {
    const sortedEvents = [...events].sort((a, b) => new Date(`${a.date}T${a.time}`).getTime() - new Date(`${b.date}T${b.time}`).getTime());

    return (
        <div className="p-4 animate-fade-in">
            <h2 className="text-2xl font-bold text-gray-800 mb-6">Upcoming Events & Tasks</h2>
            {sortedEvents.length === 0 ? (
                <div className="text-center text-gray-500 mt-10">
                    <p>Your calendar is empty.</p>
                    <p className="text-sm">Try scheduling something in the chat!</p>
                </div>
            ) : (
                <ul className="space-y-4">
                    {sortedEvents.map(event => {
                        const completedSubtasks = event.subtasks?.filter(s => s.completed).length || 0;
                        const totalSubtasks = event.subtasks?.length || 0;

                        return (
                        <li key={event.id} className="bg-white p-4 rounded-lg shadow-sm border-l-4 border-brand-secondary">
                            <div className="flex justify-between items-start">
                                <div>
                                    <h3 className="font-semibold text-gray-900">{event.title}</h3>
                                    <p className="text-sm text-gray-600">
                                        {new Date(event.date).toLocaleDateString(undefined, { weekday: 'long', month: 'long', day: 'numeric' })} at {event.time}
                                    </p>
                                </div>
                                <div className="flex flex-col items-end space-y-2">
                                    <PriorityBadge priority={event.priority} />
                                    {totalSubtasks > 0 && (
                                        <span className="text-xs font-semibold text-gray-500 bg-gray-100 px-2 py-1 rounded-md">
                                            {completedSubtasks}/{totalSubtasks}
                                        </span>
                                    )}
                                </div>
                            </div>
                            {totalSubtasks > 0 && (
                                <div className="mt-4 pt-3 border-t border-gray-200">
                                     <h4 className="text-sm font-medium text-gray-600 mb-2">Subtasks</h4>
                                     <ul className="space-y-2">
                                        {event.subtasks?.map(subtask => (
                                            <li key={subtask.id} className="flex items-center">
                                                <input
                                                    type="checkbox"
                                                    id={`subtask-${subtask.id}`}
                                                    checked={subtask.completed}
                                                    onChange={() => onToggleSubtask(event.id, subtask.id)}
                                                    className="h-4 w-4 rounded border-gray-300 text-brand-secondary focus:ring-brand-secondary cursor-pointer"
                                                />
                                                <label htmlFor={`subtask-${subtask.id}`} className={`ml-3 text-sm cursor-pointer ${subtask.completed ? 'text-gray-400 line-through' : 'text-gray-800'}`}>
                                                    {subtask.text}
                                                </label>
                                            </li>
                                        ))}
                                    </ul>
                                </div>
                            )}
                        </li>
                    )})}
                </ul>
            )}
        </div>
    );
};
