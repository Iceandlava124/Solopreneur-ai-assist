
import React from 'react';
import type { Insight } from '../types';

interface DashboardViewProps {
    insights: Insight[];
}

const InsightCard: React.FC<{ title: string; children: React.ReactNode, icon: string }> = ({ title, children, icon }) => (
    <div className="bg-white p-6 rounded-lg shadow-md border border-gray-200 animate-fade-in">
        <div className="flex items-center mb-3">
            <span className="text-2xl mr-3">{icon}</span>
            <h3 className="text-lg font-semibold text-gray-800">{title}</h3>
        </div>
        {children}
    </div>
);


export const DashboardView: React.FC<DashboardViewProps> = ({ insights }) => {
    if (insights.length === 0) {
        return (
            <div className="p-4 text-center text-gray-500">
                <p>No insights generated yet.</p>
                <p className="text-sm">Upload an image in the chat to get started.</p>
            </div>
        );
    }

    const latestInsight = insights[0];

    return (
        <div className="p-4 space-y-6">
            <h2 className="text-2xl font-bold text-gray-800">Business Insights</h2>
            
            <InsightCard title="Summary" icon="📝">
                <p className="text-gray-600">{latestInsight.summary}</p>
            </InsightCard>

            <InsightCard title="Key Trends" icon="📈">
                <ul className="list-disc list-inside space-y-2 text-gray-600">
                    {latestInsight.trends.map((trend, index) => <li key={index}>{trend}</li>)}
                </ul>
            </InsightCard>
            
            <InsightCard title="Actionable Steps" icon="🎯">
                 <ul className="list-decimal list-inside space-y-2 text-gray-600">
                    {latestInsight.actions.map((action, index) => <li key={index}>{action}</li>)}
                </ul>
            </InsightCard>
        </div>
    );
};
