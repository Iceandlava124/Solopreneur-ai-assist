
import React from 'react';

type ConnectionState = 'disconnected' | 'connecting' | 'connected' | 'error';

interface VoiceAssistantViewProps {
    connectionState: ConnectionState;
    toggleConnection: () => void;
    transcript: { speaker: 'user' | 'ai', text: string }[];
}

export const VoiceAssistantView: React.FC<VoiceAssistantViewProps> = ({ connectionState, toggleConnection, transcript }) => {

    const getButtonState = () => {
        switch (connectionState) {
            case 'disconnected':
                return { text: 'Start Conversation', icon: '▶', color: 'bg-green-500 hover:bg-green-600', disabled: false };
            case 'connecting':
                return { text: 'Connecting...', icon: '…', color: 'bg-yellow-500', disabled: true };
            case 'connected':
                return { text: 'Stop Conversation', icon: '■', color: 'bg-red-500 hover:bg-red-600', disabled: false };
            case 'error':
                 return { text: 'Connection Error', icon: '!', color: 'bg-gray-500', disabled: true };
        }
    }

    const buttonState = getButtonState();

    return (
        <div className="flex flex-col h-full w-full items-center justify-between p-6 bg-brand-dark text-white animate-fade-in">
            <div className="w-full max-w-2xl text-center">
                <h2 className="text-3xl font-bold mb-2">Voice Assistant</h2>
                <p className="text-blue-200">Speak naturally and I'll respond in real-time.</p>
            </div>

            <div className="flex-1 w-full max-w-2xl bg-gray-900 bg-opacity-50 rounded-lg my-6 p-4 overflow-y-auto">
                {transcript.length === 0 && (
                    <div className="flex items-center justify-center h-full text-gray-400">
                        <p>Press "Start" to begin the conversation.</p>
                    </div>
                )}
                <ul className="space-y-4">
                    {transcript.map((entry, index) => (
                        <li key={index} className={`flex items-start gap-3 ${entry.speaker === 'user' ? 'justify-end' : 'justify-start'}`}>
                            {entry.speaker === 'ai' && <span className="text-xl">🤖</span>}
                            <div className={`px-4 py-2 rounded-lg max-w-md ${entry.speaker === 'user' ? 'bg-blue-600 text-right' : 'bg-gray-700'}`}>
                                <p>{entry.text}</p>
                            </div>
                            {entry.speaker === 'user' && <span className="text-xl">👤</span>}
                        </li>
                    ))}
                </ul>
            </div>
            
            <button
                onClick={toggleConnection}
                disabled={buttonState.disabled}
                className={`flex items-center justify-center w-48 h-16 rounded-full text-white font-bold text-lg transition-all duration-300 shadow-lg ${buttonState.color} disabled:opacity-75 disabled:cursor-not-allowed`}
            >
                <span className="mr-3">{buttonState.icon}</span>
                {buttonState.text}
            </button>
        </div>
    );
};
