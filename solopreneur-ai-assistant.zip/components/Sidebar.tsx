
import React from 'react';
import type { Module } from '../types';
import { MODULES } from '../constants';

interface SidebarProps {
    activeModule: Module;
    setActiveModule: (module: Module) => void;
    isOpen: boolean;
    setIsOpen: (isOpen: boolean) => void;
}

export const Sidebar: React.FC<SidebarProps> = ({ activeModule, setActiveModule, isOpen, setIsOpen }) => {
    const handleModuleClick = (module: Module) => {
        setActiveModule(module);
        if (window.innerWidth < 768) {
            setIsOpen(false);
        }
    };
    
    return (
        <>
            <div className={`fixed inset-0 bg-black bg-opacity-50 z-30 md:hidden transition-opacity ${isOpen ? 'opacity-100' : 'opacity-0 pointer-events-none'}`} onClick={() => setIsOpen(false)}></div>
            <aside className={`absolute md:relative flex flex-col w-64 bg-brand-primary text-white h-full transition-transform transform ${isOpen ? 'translate-x-0' : '-translate-x-full'} md:translate-x-0 z-40`}>
                <div className="flex items-center justify-center p-6 border-b border-blue-800">
                    <span className="text-2xl mr-2">🚀</span>
                    <h1 className="text-2xl font-bold tracking-wider">Solo AI</h1>
                </div>
                <nav className="flex-1 p-4">
                    <ul>
                        {MODULES.map((module) => (
                            <li key={module.id}>
                                <button
                                    onClick={() => handleModuleClick(module)}
                                    className={`flex items-center w-full text-left p-3 my-1 rounded-lg transition-colors duration-200 ${
                                        activeModule.id === module.id
                                            ? 'bg-brand-secondary text-white shadow-md'
                                            : 'text-blue-100 hover:bg-blue-700'
                                    }`}
                                >
                                    <span className="text-2xl mr-4">{module.icon}</span>
                                    <span className="font-medium">{module.name}</span>
                                </button>
                            </li>
                        ))}
                    </ul>
                </nav>
                <div className="p-4 border-t border-blue-800 text-center text-xs text-blue-300">
                    <p>&copy; {new Date().getFullYear()} Solopreneur AI Assistant</p>
                </div>
            </aside>
        </>
    );
};
